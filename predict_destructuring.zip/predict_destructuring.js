// 1)
const cars = ["Tesla", "Mercedes", "Honda"];
const [randomCar] = cars;
const [, otherRandomCar] = cars;
//Predict the output
console.log(randomCar);
console.log(otherRandomCar);
// OUTPUT:
// 'Tesla'
// 'Mercedes'

// 2)
const employee = {
  name: "Elon",
  age: 47,
  company: "Tesla",
};
const { name: otherName } = employee;
//Predict the output
console.log(name);
console.log(otherName);
// OUTPUT:
// Error
// ''name' has not been declared as a constant in the global scope, not defined

// 3)
const person = {
  name: "Phil Smith",
  age: 47,
  height: "6 feet",
};
const password = "12345";
const { password: hashedPassword } = person;
//Predict the output
console.log(password);
console.log(hashedPassword);
// OUTPUT:
//
// '12345'
// undefined (any)

// 4)
const numbers = [8, 2, 3, 5, 6, 1, 67, 12, 2];
const [, first] = numbers; //equivalent to saying "of this array of numbers, skip the first index and rename the 2nd index to 'first"
const [, , , second] = numbers; //equivalent to saying "of this array of numbers, skip the first 3 indexes and rename the 4th index to 'second"
const [, , , , , , , , third] = numbers; //equivalent to saying "of this array of numbers, skip the first 8 indexes and rename the 9th index to 'third"
//Predict the output
console.log(first == second); //is 'first' (defined above) equal to 'second' / 2==5 NO
console.log(first == third); //is 'first (defined above) equal to 'third' / 2==2 YES
// OUTPUT:
// False
// True

//5)
const lastTest = {
  key: "value",
  secondKey: [1, 5, 1, 8, 3, 3],
};
const { key } = lastTest;
const { secondKey } = lastTest;
const [, willThisWork] = secondKey;
//Predict the output
console.log(key);
console.log(secondKey);
console.log(secondKey[0]);
console.log(willThisWork);
// OUTPUT:
// 'value'
// '[1, 5, 1, 8, 3, 3]'
// '1'
// '5'
